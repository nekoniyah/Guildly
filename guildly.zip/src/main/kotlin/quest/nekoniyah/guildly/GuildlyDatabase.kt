package quest.nekoniyah.guildly

import org.jetbrains.exposed.v1.jdbc.Database


object GuildlyDatabase {
    var database: Database? = null

    fun init(): Database {
        val databaseInstance = Database.connect("jdbc:sqlite:/${Guildly.ID}/guilds.db", "org.sqlite.JDBC")
        database = databaseInstance
        return databaseInstance
    }
}