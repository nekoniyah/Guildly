package quest.nekoniyah.guildly

import net.neoforged.api.distmarker.Dist
import net.neoforged.bus.api.SubscribeEvent
import net.neoforged.fml.common.EventBusSubscriber
import net.neoforged.fml.common.Mod
import net.neoforged.neoforge.event.server.ServerStartingEvent
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger

/**
 * Main mod class.
 *
 * An example for blocks is in the `blocks` package of this mod.
 */
@Mod(Guildly.ID)
@EventBusSubscriber(value = [Dist.DEDICATED_SERVER])
object Guildly {
    const val ID = "guildly"

    // the logger for our mod
    val LOGGER: Logger = LogManager.getLogger(ID)

    @SubscribeEvent
    fun onCommonSetup(event: ServerStartingEvent) {
        GuildlyDatabase.init()
        LOGGER.log(Level.INFO, "Hello! This is working!")
    }
}
